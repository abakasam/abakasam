This Zip file contains a HTML template for use when submitting articles
to The Code Project. We recommend editing these files using DevStudio
or WordPad. We will remove all extraneous formatting. 

If you use the HTML template then it will not look like the final product - 
it has been formatted to allow the relevant information to be entered as
quickly and easily as possible. 

Using this template will help us post your article sooner. To use, just 
follow the 3 easy steps below:
 
     1. Fill in the article description details
     2. Add links to your images and downloads
     3. Include the main article text

That's all there is to it! All formatting will be done by our submission
scripts and style sheets. 

The Code Project
www.codeproject.com